<?php
	//PHP Web Service Azure 
	 header('Content-Type: application/json'); //establece el formato json como formato a devolver
	 header("Access-Control-Allow-Origin: *");
	 header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
	
	$username="xxx"; //nombre de usuario 
	$password="xxx";	//contraseña
	$hostname="xxx"; //nombre de host
	
	$dbhandle=mysql_connect($hostname, $username, $password) //manejador de la base de datos
	or die("No es posible conectarse a MySQL"); //mensaje si aparece se genera error
	$seleccion=mysql_select_db("notas_materias") //nombre de la base de datos
	or die("Base de datos no disponible"); //mensaje si aparece se genera error
	
	function mostrar_registros($detalle){	//funcion para mostrar los registros
		$consulta=mysql_query("SELECT * FROM ".$detalle); //establece consulta
		while($fila=mysql_fetch_assoc($consulta)){ //verifica y lee los registros
			$registros[]=$fila; //guarda los registros respuesta en $registros[]
		}
		return $registros; //retorna los registros de la consulta
	}	
	//Programación de las peticiones al web service
	if($_GET['peticion']=='general'){ //verbo GET
		$resultados=mostrar_registros($_GET['detalle']); //si peticion==general, lle detalle
	}else{
		header('HTTP/1.1 405 Method Not Allowed'); //muestra mensaje si se genera error
		exit;
	}
	echo json_encode($resultados); //codificación del resultado en formato json
?>
